﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeioMundo.API
{
    public class Classes
    {
        public class Produtos
        {
            public string _Ref;
            public int _Stock;
            public float _Preço;
        }
    }
}
